// Coupon Modal Functionality
document.addEventListener('DOMContentLoaded', function() {
    const couponSelect = document.getElementById('couponSelect');
    const couponModal = document.getElementById('couponModal');
    const couponList = document.getElementById('couponList');
    const checkCouponButton = document.getElementById('checkCoupon');
    const selectedCouponDisplay = document.getElementById('selectedCouponDisplay');
    const selectedCouponText = document.getElementById('selectedCouponText');
    const clearCouponButton = document.getElementById('clearCoupon');

    // Open modal when select is clicked
    couponSelect.addEventListener('click', function(e) {
        e.preventDefault();
        openModal();
    });

    // Close modal when clicking outside
    couponModal.addEventListener('click', function(e) {
        if (e.target === couponModal) {
            closeModal();
        }
    });

    // Populate coupon list
    function populateCouponList() {
        couponList.innerHTML = '';
        Array.from(couponSelect.options).forEach(option => {
            if (option.value) {
                const couponDiv = document.createElement('div');
                couponDiv.className = 'bg-gray-100 rounded-lg p-3 flex items-center space-x-3 cursor-pointer hover:bg-gray-200 transition-colors';
                couponDiv.innerHTML = `
                    <span class="material-icons text-gray-600">local_offer</span>
                    <div class="flex-grow">
                        <p class="font-semibold">${option.text.split('-')[0].trim()}</p>
                        <p class="text-sm text-gray-600">${option.text.split('-')[1].trim()}</p>
                    </div>
                    <span class="material-icons text-green-500 opacity-0 transition-opacity">check_circle</span>
                `;
                couponDiv.dataset.value = option.value;
                couponDiv.addEventListener('click', selectCoupon);
                couponList.appendChild(couponDiv);
            }
        });
        updateSelectedCouponDisplay();
    }

    // Select coupon
    function selectCoupon(e) {
        const selectedValue = e.currentTarget.dataset.value;
        couponSelect.value = selectedValue;
        couponSelect.dispatchEvent(new Event('change'));
        updateSelectedCouponDisplay();
        closeModal();
    }

    // Update selected coupon display
    function updateSelectedCouponDisplay() {
        const selectedOption = couponSelect.selectedOptions[0];
        if (selectedOption && selectedOption.value) {
            selectedCouponText.textContent = selectedOption.text;
            selectedCouponDisplay.classList.remove('hidden');
            
            // Update check icon in coupon list
            document.querySelectorAll('#couponList > div').forEach(div => {
                const checkIcon = div.querySelector('.material-icons:last-child');
                if (div.dataset.value === selectedOption.value) {
                    checkIcon.classList.remove('opacity-0');
                } else {
                    checkIcon.classList.add('opacity-0');
                }
            });
        } else {
            selectedCouponDisplay.classList.add('hidden');
        }
    }

    // Clear selected coupon
    clearCouponButton.addEventListener('click', function() {
        couponSelect.value = '';
        couponSelect.dispatchEvent(new Event('change'));
        updateSelectedCouponDisplay();
        closeModal();
    });

    // Open modal with animation
    function openModal() {
        populateCouponList();
        couponModal.classList.add('active');
        setTimeout(() => {
            couponModal.querySelector('.modal-content').style.transform = 'translateY(0)';
        }, 10);
    }

    // Close modal with animation
    function closeModal() {
        couponModal.querySelector('.modal-content').style.transform = 'translateY(100%)';
        setTimeout(() => {
            couponModal.classList.remove('active');
        }, 300);
    }

    // Dummy check coupon functionality
    checkCouponButton.addEventListener('click', function() {
        alert('Coupon check functionality would go here.');
    });
});